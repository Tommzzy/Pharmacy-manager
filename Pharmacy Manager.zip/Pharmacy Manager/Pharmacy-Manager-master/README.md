An app for pharmacy management. A user can add medicines and patients, and assign medicines to patients. Dosage time can also be set and is also recorded and color coded
